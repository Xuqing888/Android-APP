package rafe.org.hw9;

public class Constant {
    public static final String BASE_URL = "http://hw8-env.w35epu8ifw.us-east-2.elasticbeanstalk.com";
    public static final String AUTOCOMPLETE_URL = "http://hw8-env.w35epu8ifw.us-east-2.elasticbeanstalk.com/autocomplete/";
    public static final String NEWS_URL = "http://hw8-env.w35epu8ifw.us-east-2.elasticbeanstalk.com/news/";

    public static final String WEBVIEW_BASE_URL = BASE_URL;
//      public static final String WEBVIEW_BASE_URL = "http://192.168.0.111:8383";
}
