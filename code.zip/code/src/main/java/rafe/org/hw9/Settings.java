package rafe.org.hw9;

/**
 * Created by liao on 2017/11/28.
 */

import android.content.Context;
import android.content.SharedPreferences;

public class Settings {

    private static Settings settings = null;

    private final static String PREFER_NAME = "settings";    //应用设置名称
    private final static String FAVO_LIST = "favorite_list";
    private final static String SPLIT = "@@";

    private SharedPreferences sp;
    private SharedPreferences.Editor editor;

    private Settings(Context context) {
        sp = context.getSharedPreferences(PREFER_NAME, Context.MODE_PRIVATE);
        editor = sp.edit();
    }

    /**
     * 获得单例
     *
     * @return
     */
    public static Settings getInstance(Context context) {
        if (settings == null) {
            settings = new Settings(context);
        }
        return settings;
    }

    String[] getFavoList() {
        String[] list = sp.getString(FAVO_LIST, "").split(SPLIT);
        if(list.length == 1 && list[0].isEmpty()){
            return new String[0];
        }
        else{
            return list;
        }
    }

    void setFavoList(String[] favolist) {
        StringBuilder sb = new StringBuilder();
        for(String s : favolist){
            sb.append(s);
            sb.append(SPLIT);
        }
        editor.putString(FAVO_LIST, sb.toString());
        editor.commit();
    }

    void addFavoList(String favo){
        editor.putString(FAVO_LIST, sp.getString(FAVO_LIST, "") + favo + SPLIT);
        editor.commit();
    }

    void deleteFromFavoList(String favo){
        String[] temp = getFavoList();
        String[] result = new String[temp.length - 1];
        int i = 0;
        for(String s : temp){
            if(!s.equals(favo)){
                result[i] = s;
                i ++;
            }
        }
        setFavoList(result);
    }

    boolean isInFavoList(String favo){
        for(String s : getFavoList()){
            if(s.equals(favo)){
                return true;
            }
        }
        return false;
    }

}
