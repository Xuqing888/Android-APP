package rafe.org.hw9;

import android.app.Application;
import android.content.Context;

import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;

import org.litepal.LitePalApplication;



public class MyApplication extends Application {
    private static Context context;
    private static Application application;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        application = this;
        LitePalApplication.initialize(context);
        FacebookSdk.setApplicationId("151701188685023");
        AppEventsLogger.activateApp(getApplication());
        FacebookSdk.sdkInitialize(getApplicationContext());
    }

    public static Context getContext() {
        return context;
    }

    public static Application getApplication(){
        return application;
    }
}
