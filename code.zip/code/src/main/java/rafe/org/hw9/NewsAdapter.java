package rafe.org.hw9;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;


public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {
    private List<NewsItem> mNewsList;
    private Activity mActivity;

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView author;
        TextView date;

        public ViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.title);
            author = (TextView) view.findViewById(R.id.author);
            date = (TextView) view.findViewById(R.id.date);
        }
    }

    public NewsAdapter(
            Activity activity,
            List<NewsItem> planList) {
        mNewsList = planList;
        mActivity = activity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.news, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final NewsItem news = mNewsList.get(position);
        holder.title.setText(news.title);
        holder.author.setText("Author: " + news.author);
        holder.date.setText("Date: " + news.date.replace("-0500","PDT"));
        holder.title.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(news.url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        MyApplication.getContext().startActivity(i);
                    }
                }
        );
    }

    @Override
    public int getItemCount() {
        return mNewsList.size();
    }
}