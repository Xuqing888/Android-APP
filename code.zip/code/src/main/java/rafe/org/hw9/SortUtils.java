package rafe.org.hw9;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class SortUtils {
    static void sortBySymbol(List<FavoriteItem> list, final int order){
        Collections.sort(
                list, new Comparator<FavoriteItem>() {
                    @Override
                    public int compare(FavoriteItem o1, FavoriteItem o2) {
                        if(order > 0) {
                            return o1.Symbol.compareTo(o2.Symbol);
                        }
                        else{
                            return -o1.Symbol.compareTo(o2.Symbol);
                        }
                    }
                }
        );
    }
    static void sortByPrice(List<FavoriteItem> list, final int order){
        Collections.sort(
                list, new Comparator<FavoriteItem>() {
                    @Override
                    public int compare(FavoriteItem o1, FavoriteItem o2) {
                        if(order > 0) {
                            return Double.valueOf(o1.Price).compareTo(o2.Price);
                        }
                        else{
                            return - Double.valueOf(o1.Price).compareTo(o2.Price);
                        }
                    }
                }
        );
    }
    static void sortByVolume(List<FavoriteItem> list, final int order){
        Collections.sort(
                list, new Comparator<FavoriteItem>() {
                    @Override
                    public int compare(FavoriteItem o1, FavoriteItem o2) {
                        if(order > 0) {
                            return Double.valueOf(o1.Volume).compareTo(o2.Volume);
                        }
                        else{
                            return - Double.valueOf(o1.Volume).compareTo(o2.Volume);
                        }
                    }
                }
        );
    }
    static void sortByChange(List<FavoriteItem> list, final int order){
        Collections.sort(
                list, new Comparator<FavoriteItem>() {
                    @Override
                    public int compare(FavoriteItem o1, FavoriteItem o2) {
                        if(order > 0) {
                            return Double.valueOf(o1.Change).compareTo(o2.Change);
                        }
                        else{
                            return - Double.valueOf(o1.Change).compareTo(o2.Change);
                        }
                    }
                }
        );
    }
     static void sortByChangePercent(List<FavoriteItem> list, final int order){
        Collections.sort(
                list, new Comparator<FavoriteItem>() {
                    @Override
                    public int compare(FavoriteItem o1, FavoriteItem o2) {
                        if(order > 0) {
                            return Double.valueOf(o1.ChangePercent).compareTo(o2.ChangePercent);
                        }
                        else{
                            return - Double.valueOf(o1.ChangePercent).compareTo(o2.ChangePercent);
                        }
                    }
                }
        );
    }
}
