package rafe.org.hw9;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {
    private List<FavoriteItem> mFavoList;
    public MainActivity mActivity;

    static class ViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
        LinearLayout ll;
        TextView tvSymbol;
        TextView tvVolume;
        TextView tvPercent;
        final MainActivity mContext;

        public ViewHolder(View view, MainActivity context) {
            super(view);
            mContext = context;
            ll = (LinearLayout) view;
            tvSymbol = (TextView) view.findViewById(R.id.symbol);
            tvVolume = (TextView) view.findViewById(R.id.volume);
            tvPercent = (TextView) view.findViewById(R.id.percent);
            view.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Remove from Favorites?");
            MenuItem No = menu.add(Menu.NONE, 1, 1, "No");
            MenuItem Yes = menu.add(Menu.NONE, 2, 2, "Yes");
            Yes.setOnMenuItemClickListener(
                    new MenuItem.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            String itemToDelete = mContext.favoriteItemList.get(getAdapterPosition()).Symbol;
                            Settings.getInstance(MyApplication.getContext()).deleteFromFavoList(itemToDelete);
                            mContext.favoriteItemList.remove(getAdapterPosition());
                            mContext.refreshListView(mContext.favoriteItemList);
                            return true;
                        }
                    }
            );
        }
    }

    public FavoriteAdapter(
            Activity activity,
            List<FavoriteItem> planList) {
        mFavoList = planList;
        mActivity =(MainActivity) activity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.favorite_item, parent, false);
        ViewHolder holder = new ViewHolder(view, mActivity);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final FavoriteItem favo = mFavoList.get(position);
        holder.tvSymbol.setText(favo.Symbol);
        holder.tvVolume.setText(String.format("%.2f", favo.Price));
        holder.tvPercent.setText(String.format("%.2f", favo.Change) + "(" + String.format("%.2f", favo.ChangePercent) + "%)");
        holder.ll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(MyApplication.getContext(), TabActivity.class);
                        i.putExtra(Intent.EXTRA_TEXT, favo.Symbol);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        MyApplication.getContext().startActivity(i);
                    }
                }
        );
        if(favo.Change > 0){
            holder.tvPercent.setTextColor(
                    Color.GREEN
            );
        }
        else{
            holder.tvPercent.setTextColor(
                    Color.RED
            );
        }
    }

    @Override
    public int getItemCount() {
        return mFavoList.size();
    }
}