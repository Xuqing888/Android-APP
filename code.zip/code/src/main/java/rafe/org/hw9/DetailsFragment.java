package rafe.org.hw9;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.service.carrier.CarrierMessagingService;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;


public class DetailsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_CODE = "";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParamCode;
    private String mParam2;

    WebView webViewHist;
    ImageButton btnFavorite;
    ImageButton btnFacebook;
    Settings settings;
    JavaInject jsInterface;
    boolean mLoad = false;

    boolean added = false;

    public DetailsFragment() {
        // Required empty public constructor
    }

    public static DetailsFragment newInstance(String code) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CODE, code);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParamCode = getArguments().getString(ARG_CODE);
        }
        //Toast.makeText(getActivity(), "code = " + mParamCode, Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onStart() {
        super.onStart();
        jsInterface = new JavaInject(this);
        settings = Settings.getInstance(MyApplication.getContext());
        webViewHist = (WebView) getView().findViewById(R.id.webViewDetail);
        WebSettings webSettings = webViewHist.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webViewHist.addJavascriptInterface(jsInterface, "android");
        webViewHist.setWebViewClient(
                new WebViewClient(){
                    @Override
                    public void onLoadResource(WebView view, String url) {
                        if(mLoad){
                            return ;
                        }
                        super.onLoadResource(view, url);
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        super.onPageFinished(view, url);
                        mLoad = true;
                    }
                }
        );
        String url = Constant.WEBVIEW_BASE_URL + "/details.html?code=" + mParamCode;
        if(webViewHist.getUrl() != null && webViewHist.getUrl().equals(url)) {

        }
        else{
            webViewHist.loadUrl(url);
        }

        btnFavorite = (ImageButton) getView().findViewById(R.id.favor);
        btnFacebook = (ImageButton) getView().findViewById(R.id.facebook);

        if(settings.isInFavoList(mParamCode)){
            btnFavorite.setBackground(
                    MyApplication
                    .getContext().getResources().getDrawable(R.drawable.star_filled)
            );
        }

        btnFavorite.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!settings.isInFavoList(mParamCode)) {
                            settings.addFavoList(mParamCode);
                            btnFavorite.setBackground(ContextCompat.getDrawable(MyApplication.getContext(), R.drawable.star_filled));
                            added = true;
                            for(String s : settings.getFavoList()){
                                Log.d("favolist", s);
                            }
                        }
                        else{
                            settings.deleteFromFavoList(mParamCode);
                            btnFavorite.setBackground(
                                    ContextCompat.getDrawable(MyApplication.getContext(),
                                            R.drawable.star_empty
                                    )
                            );
                        }
                    }
                }
        );

        btnFacebook.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        webViewHist.evaluateJavascript("get_current_pic()",
                                new ValueCallback<String>() {
                                    @Override
                                    public void onReceiveValue(String value) {
                                        value = value.substring(1,value.length() - 1);
                                        if(value.trim().isEmpty()){
                                            Toast.makeText(MyApplication.getContext(), "no picture to share!", Toast.LENGTH_SHORT).show();
                                        }
                                        else{
                                            ShareDialog shareDialog;
                                            //Toast.makeText(MyApplication.getContext(), value, Toast.LENGTH_SHORT).show();
                                            shareDialog = new ShareDialog(getActivity());
                                            ShareLinkContent content = new ShareLinkContent.Builder()
                                                    .setContentUrl(Uri.parse(value))
                                                    .build();
                                            ShareDialog.show(DetailsFragment.this, content);
                                        }
                                    }
                                }
                        );
                    }
                }
        );
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("HistFragment", "OnPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("HistFragment", "OnPause");
    }

    public void onVisible(){
        if(getActivity() != null) {
            Toast.makeText(getActivity(), "I'm Visible!", Toast.LENGTH_SHORT).show();
        }
    }
}
