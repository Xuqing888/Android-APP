package rafe.org.hw9;

//<item>Default</item>
//<item>Symbol</item>
//<item>Price</item>
//<item>Change</item>
//<item>Change Percent</item>
//<item>Volume</item>

public class FavoriteItem {
    String Symbol;
    double Price;
    double Change;
    double ChangePercent;
    double Volume;

    public FavoriteItem(String sb, double pr, double cg, double cp, double vo){
        Symbol = sb;
        Price = pr;
        Change = cg;
        ChangePercent = cp;
        Volume = vo;
    }
}
