package rafe.org.hw9;

/**
 * Created by liao on 2017/11/28.
 */

public class NewsItem {
    String title;
    String url;
    String author;
    String date;
    public NewsItem(String title, String url, String author, String date){
        this.title = title;
        this.url = url;
        this.author = author;
        this.date = date;
    }
}
