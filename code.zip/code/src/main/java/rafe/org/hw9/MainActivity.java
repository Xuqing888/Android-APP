package rafe.org.hw9;

import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;

public class MainActivity extends AppCompatActivity {

    private static RequestQueue requestQueue;
    private TextView tvGetQuota;
    private TextView tvClear;
    private ImageButton btnRefresh;
    private Switch switchAutoRefresh;
    private AutoCompleteTextView act;
    private Spinner sortBySpinner;
    private Spinner orderSpinner;
    private List<String> suggest = new ArrayList<>();
    List<FavoriteItem> favoriteItemList = new ArrayList<>();
    private Settings settings;
    private RecyclerView favoBox;
    ProgressBar progressBar;
    private TextView tvErrorMessage;
    final static int REFRESH = 3;

    final android.os.Handler mHandler = new android.os.Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case REFRESH:
                    fetchFavo();
                    break;
                default:
                    break;
            }
        }
    };

    Timer timer;

    TimerTask task;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        assignLayout();
        initRequestQueue();
        initAct();
        if(getActionBar() == null){
            getSupportActionBar().hide();
        }
        else{
            getActionBar().hide();
        }

        settings = Settings.getInstance(this);

        tvClear.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        act.setText("");
                    }
                }
        );

        tvGetQuota.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = act.getText().toString();
                        if(text.trim().isEmpty()){
                            Toast.makeText(MainActivity.this, "Please enter a stock name or symbol", Toast.LENGTH_SHORT).show();
                            return ;
                        }

                        Intent intent = new Intent(MainActivity.this, TabActivity.class);
                        intent.putExtra(Intent.EXTRA_TEXT, text.trim());
                        startActivity(intent);
                    }
                }
        );

        btnRefresh.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        fetchFavo();
                        String str = "";
                        for(String s : settings.getFavoList()){
                            str += s;
                        }
                        Toast.makeText(MainActivity.this, "fetching:" + str, Toast.LENGTH_SHORT).show();
                    }
                }
        );

        switchAutoRefresh.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(isChecked){
                            timer = new Timer(true);
                            task = new TimerTask() {
                                @Override
                                public void run() {
                                    Message message = mHandler.obtainMessage();
                                    message.what = REFRESH;
                                    mHandler.sendMessage(message);
                                }
                            };
                            timer.scheduleAtFixedRate(task, 10000L, 10000L);
                        }
                        else{
                            timer.cancel();
                            timer = null;
                            task = null;
                        }
                    }
                }
        );
//        <item>Default</item>
//        <item>Symbol</item>
//        <item>Price</item>
//        <item>Change</item>
//        <item>Change Percent</item>
//        <item>Volume</item>
        List<String> sortByList = new ArrayList<>();
        sortByList.add("Default");
        sortByList.add("Symbol");
        sortByList.add("Price");
        sortByList.add("Change");
        sortByList.add("Change Percent");
        sortByList.add("Volume");
        sortByList.add("Sort By");
        HintAdapter hintAdapter = new HintAdapter(this, sortByList, android.R.layout.simple_spinner_dropdown_item);
        sortBySpinner.setAdapter(hintAdapter);
        sortBySpinner.setSelection(sortByList.size() - 1);
        sortBySpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        refreshListView(favoriteItemList);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );

        List<String> orderList = new ArrayList<>();
        orderList.add("Ascending");
        orderList.add("Descending");
        orderList.add("Order");
        HintAdapter hintAdapter1 = new HintAdapter(this, orderList, android.R.layout.simple_spinner_dropdown_item);
        orderSpinner.setAdapter(hintAdapter1);
        orderSpinner.setSelection(orderList.size() - 1 );

        orderSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        refreshListView(favoriteItemList);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );
    }

    private void initAct() {
        act.addTextChangedListener(new TextWatcher(){

            public void afterTextChanged(Editable editable) {

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s == null || s.toString().trim().isEmpty()){
                    return ;
                }

                String query = Constant.AUTOCOMPLETE_URL + s.toString();
                Log.d("onTextChanged", query);
                JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, query, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray jarray) {
                        Log.d("cylog", jarray.toString());
                        try {
                            suggest.clear();
                            for (int i = 0; i < jarray.length(); i++) {
                                JSONObject obj = jarray.getJSONObject(i);
                                String symbol = obj.getString("Symbol");
                                String name = obj.getString("Name");
                                String Exchange = obj.getString("Exchange");
                                if(i == 5){
                                    break;
                                }
                                suggest.add(symbol + " - " + name + "(" + Exchange + ")");
                                //suggest.add(symbol);
                            }
                            ArrayAdapter<String> aAdapter = new ArrayAdapter<String>(MainActivity.this,
                                    android.R.layout.simple_spinner_dropdown_item
                                    , suggest);
                            act.setAdapter(aAdapter);
                           // act.setDropDownBackgroundDrawable(ContextCompat.getDrawable(MyApplication.getContext(), android.R.drawable.screen_background_light));
                            act.setThreshold(1);
                            act.setOnItemClickListener(
                                    new AdapterView.OnItemClickListener() {
                                        @Override
                                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                            act.setText(suggest.get(position).replaceAll(" -.+$",""));
                                        }
                                    }
                            );
                            aAdapter.notifyDataSetChanged();
                        }
                        catch (JSONException je){
                            je.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        volleyError.printStackTrace();
                    }
                });
                requestQueue.add(jsonArrayRequest);

            }

        });
    }

    void fetchFavo(){
        requestQueue.cancelAll(new RequestQueue.RequestFilter() {
            @Override
            public boolean apply(Request<?> request) {
                return true;
            }
        });
        favoriteItemList.clear();
        tvErrorMessage.setText("");
        String[] list = settings.getFavoList();
        if(list.length == 0){
            Toast.makeText(this, "No favorite items", Toast.LENGTH_SHORT).show();
            return;
        }
        showProgress();
        for(String symbol : settings.getFavoList()){
            fetchOnePrice(symbol);
        }
    }

    void fetchOnePrice(final String symbol){
        String query = Constant.BASE_URL + "/price/" + symbol;
        JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Request.Method.GET, query, null, new Response.Listener<JSONObject>() {
            @Override
                    public void onResponse(JSONObject jsonObject) {
                        //Log.d("cylog", jarray.toString());
                        try {
                            suggest.clear();
                            List<String> dateList = new ArrayList<>();
                            JSONObject timeSeries = jsonObject.getJSONObject("Time Series (Daily)");
                            JSONArray jarray = timeSeries.names();
                            for(int i = 0; i < jarray.length(); i ++){
                                dateList.add(jarray.getString(i));
                            }
                            if(jarray.length() < 2){
                                throw new JSONException("data not enough");
                            }
                            String lastDay = dateList.get(0);
                            String lastDayYesteday = dateList.get(1);
                            double volume = timeSeries.getJSONObject(lastDay).getDouble("5. volume");
                            double priceLastDay = timeSeries.getJSONObject(lastDay).getDouble("4. close");
                            double priceLastDayYesterday = timeSeries.getJSONObject(lastDayYesteday).getDouble("4. close");
                            double change = priceLastDay - priceLastDayYesterday;
                            double changePercent = (change / priceLastDayYesterday) * 100;
                            FavoriteItem fi = new FavoriteItem(symbol, priceLastDay, change, changePercent, volume);
                            favoriteItemList.add(fi);
                            //refreshListView(favoriteItemList);
                            //all data fetched
                            if(favoriteItemList.size() == settings.getFavoList().length){
                                refreshListView(favoriteItemList);
                                hideProgress();
                            }
                        }
                        catch (JSONException je){
                            je.printStackTrace();
                            Toast.makeText(MainActivity.this, "json error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        volleyError.printStackTrace();
                        Toast.makeText(MainActivity.this, "volley error", Toast.LENGTH_SHORT).show();
                        requestQueue.cancelAll(new RequestQueue.RequestFilter() {
                            @Override
                            public boolean apply(Request<?> request) {
                                return true;
                            }
                        });
                        hideProgress();
                        tvErrorMessage.setText("Failed to load data");
                    }
                });
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(jsonArrayRequest);

    }

    @Override
    protected void onResume() {
        super.onResume();
        //Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
        fetchFavo();
    }

    void refreshListView(List<FavoriteItem> favoriteItemList) {

        int order = 0;
        if(orderSpinner.getSelectedItemPosition() == 0 || orderSpinner.getSelectedItemPosition() == 2){
            order = 1;
        }
        else{
            order = -1;
        }
        int sortByPos = sortBySpinner.getSelectedItemPosition();
        if(sortByPos == 0 || sortByPos == 6){
            List<FavoriteItem> temp = new ArrayList<>();
            for(String symbol : settings.getFavoList()){
                for(FavoriteItem item : favoriteItemList){
                    if(item.Symbol.equals(symbol)){
                        temp.add(item);
                        break;
                    }
                }
            }
            if(temp.size() == favoriteItemList.size()){
                favoriteItemList = temp;
            }
            else{
                Toast.makeText(this, "error, length not equal", Toast.LENGTH_SHORT).show();
            }
        }
        if(sortByPos == 1){
            SortUtils.sortBySymbol(favoriteItemList, order);
        }
        if(sortByPos == 2){
            SortUtils.sortByPrice(favoriteItemList, order);
        }
        if(sortByPos == 3){
            SortUtils.sortByChange(favoriteItemList, order);
        }
        if(sortByPos == 4){
            SortUtils.sortByChangePercent(favoriteItemList, order);
        }
        if(sortByPos == 5){
            SortUtils.sortByVolume(favoriteItemList, order);
        }

        favoBox.setLayoutManager(new LinearLayoutManager(MyApplication.getContext()));
        FavoriteAdapter na = new FavoriteAdapter(this, favoriteItemList);
        favoBox.setAdapter(na);
    }

    private void initRequestQueue() {
        requestQueue = Volley.newRequestQueue(getApplicationContext());
    }

    private void assignLayout() {
        tvGetQuota = (TextView) findViewById(R.id.get_quote);
        tvClear = (TextView) findViewById(R.id.clear);
        btnRefresh = (ImageButton) findViewById(R.id.btn_refresh);
        switchAutoRefresh = (Switch) findViewById(R.id.auto_refresh);
        act = (AutoCompleteTextView) findViewById(R.id.act);
        sortBySpinner = (Spinner) findViewById(R.id.sort_by);
        orderSpinner = (Spinner) findViewById(R.id.order);
        sortBySpinner.setPrompt("Sort By");
        orderSpinner.setPrompt("Order");
        favoBox = (RecyclerView) findViewById(R.id.favo_box);
        progressBar = (ProgressBar) findViewById(R.id.progress);
        tvErrorMessage = (TextView) findViewById(R.id.error_message);
    }

    //cancel auto completetextview focus
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View v = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);

        if (v instanceof AutoCompleteTextView) {
            View currentFocus = getCurrentFocus();
            int screenCoords[] = new int[2];
            currentFocus.getLocationOnScreen(screenCoords);
            float x = event.getRawX() + currentFocus.getLeft() - screenCoords[0];
            float y = event.getRawY() + currentFocus.getTop() - screenCoords[1];

            if (event.getAction() == MotionEvent.ACTION_UP
                    && (x < currentFocus.getLeft() ||
                    x >= currentFocus.getRight() ||
                    y < currentFocus.getTop() ||
                    y > currentFocus.getBottom())) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
                v.clearFocus();
            }
        }
        return ret;
    }

    void showProgress(){
        progressBar.setVisibility(View.VISIBLE);
    }

    void hideProgress(){
        progressBar.setVisibility(View.GONE);
    }

}
