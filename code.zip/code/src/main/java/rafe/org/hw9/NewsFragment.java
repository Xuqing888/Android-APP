package rafe.org.hw9;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class NewsFragment extends Fragment {
    private static RequestQueue requestQueue;
    private static final String ARG_CODE = "";
    private static final String ARG_PARAM2 = "param2";

    private String mParamCode;
    private String mParam2;

    RecyclerView newsBox;

    ProgressBar progressBarNews;

    public NewsFragment() {
        // Required empty public constructor
    }

    public static NewsFragment newInstance(String code) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CODE, code);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParamCode = getArguments().getString(ARG_CODE);
        }
        requestQueue = Volley.newRequestQueue(MyApplication.getContext());
        Toast.makeText(getActivity(), "code = " + mParamCode, Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_news, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onStart() {
        super.onStart();
        newsBox = (RecyclerView) getView().findViewById(R.id.news_box);
        progressBarNews = (ProgressBar) getView().findViewById(R.id.progress_news);
        getNews();

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("HistFragment", "OnPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("HistFragment", "OnPause");
    }

    public void onVisible(){
        if(getActivity() != null) {
            Toast.makeText(getActivity(), "I'm Visible!", Toast.LENGTH_SHORT).show();
        }
    }

    void getNews(){
        String url = Constant.NEWS_URL + mParamCode;
                    StringRequest jsonArrayRequest =
                            new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String xml) {
                        Log.d("cylog", xml.toString());
                        try {
                            List<NewsItem> bag = new ArrayList<>();
                            String xmlCorrected = xml.substring(1, xml.length() - 1)
                                    .replace("\\\"","\"")
                                    .replace("\\n","");
                            if(!xml.contains("author")){
                                throw new Exception("wrong!");
                            }
                            Log.d("corrected", xmlCorrected);
                            Document doc = Jsoup.parse(xmlCorrected, "http://127.0.0.1:9999", Parser.xmlParser());
                            for(Element ele : doc.select("item")){
                                String title = ele.selectFirst("title").text();
                                String url = ele.selectFirst("link").text();
                                String author = "";
                                for(Element e : ele.select("*")){
                                    String[] splitted = e.tagName().split(":");
                                    if(splitted.length == 2 && splitted[1].equals("author_name")){
                                        author = e.text();
                                    }
                                }
                                String date = ele.selectFirst("pubDate").text();
                                bag.add(new NewsItem(title, url, author, date));
                                Log.d("parsexml new_fragment", title);
                                Log.d("parsexml url", url);
                                Log.d("parsexml author",author);
                                Log.d("parsexml pubDate", date);
                            }
                            newsBox.setLayoutManager(new LinearLayoutManager(MyApplication.getContext()));
                            NewsAdapter na = new NewsAdapter(getActivity(), bag);
                            newsBox.setAdapter(na);
                        }
                        catch (Exception e){
                            e.printStackTrace();
                            showError();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        volleyError.printStackTrace();
                        showError();
                    }
                });
                requestQueue.add(jsonArrayRequest);

    }

    void showError(){
        TextView error = (TextView) getView().findViewById(R.id.news_error);
        error.setText("Failed to load news");
        progressBarNews.setVisibility(View.GONE);
    }

}
