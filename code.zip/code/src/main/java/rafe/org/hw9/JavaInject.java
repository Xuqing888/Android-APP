package rafe.org.hw9;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;


public class JavaInject {
    Context context;

    JavaInject(DetailsFragment fragment){

    }

    @JavascriptInterface
    public String getUrl(String url){
        Log.d("javainterface", url);
        return url;
    }
}
