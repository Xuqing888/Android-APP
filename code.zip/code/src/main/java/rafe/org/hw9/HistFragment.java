package rafe.org.hw9;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class HistFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_CODE = "";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParamCode;
    private String mParam2;

    WebView webViewHist;

    public HistFragment() {
        // Required empty public constructor
    }

    public static HistFragment newInstance(String code) {
        HistFragment fragment = new HistFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CODE, code);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParamCode = getArguments().getString(ARG_CODE);
        }
        //Toast.makeText(getActivity(), "code = " + mParamCode, Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_hist, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onStart() {
        super.onStart();
        webViewHist = (WebView) getView().findViewById(R.id.webViewHist);
        WebSettings webSettings = webViewHist.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webViewHist.loadUrl(Constant.WEBVIEW_BASE_URL + "/hist.html?code=" + mParamCode);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("HistFragment", "OnPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("HistFragment", "OnPause");
    }

    public void onVisible(){
        if(getActivity() != null) {
        }
    }

   // public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
     //   void onFragmentInteraction(Uri uri);
    //}
}
